package add_and_multiply;

public interface Element {
    Element add(Element other);
    Element multiply(Element other);
}
